import { desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { menuItems, orderItems, orders, type OrderWithItems } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import type { PlaceOrderPayload } from "@/lib/types";
import { ORDER_STATUSES } from "@/lib/types";

export const dynamic = "force-dynamic";

function generateToken(): string {
  const time = Date.now().toString(36).toUpperCase();
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `CT-${time}${rand}`;
}

export async function GET() {
  await ensureSeeded();

  const recentOrders = await db
    .select()
    .from(orders)
    .orderBy(desc(orders.createdAt))
    .limit(30);

  const items =
    recentOrders.length > 0
      ? await db
          .select()
          .from(orderItems)
          .where(
            inArray(
              orderItems.orderId,
              recentOrders.map((o) => o.id),
            ),
          )
      : [];

  const byOrder = new Map<number, typeof items>();
  for (const item of items) {
    const list = byOrder.get(item.orderId) ?? [];
    list.push(item);
    byOrder.set(item.orderId, list);
  }

  const result: OrderWithItems[] = recentOrders.map((o) => ({
    ...o,
    items: (byOrder.get(o.id) ?? []).sort((a, b) => a.id - b.id),
  }));

  return Response.json({ orders: result });
}

export async function POST(request: Request) {
  await ensureSeeded();

  let body: PlaceOrderPayload;
  try {
    body = (await request.json()) as PlaceOrderPayload;
  } catch {
    return Response.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const customerName = body.customerName?.trim();
  const rollNumber = body.rollNumber?.trim();
  const room = body.room?.trim() ?? "";
  const paymentMethod = body.paymentMethod;

  if (!customerName || customerName.length < 2) {
    return Response.json(
      { error: "Please enter your full name" },
      { status: 400 },
    );
  }
  if (!rollNumber || rollNumber.length < 3) {
    return Response.json(
      { error: "Please enter a valid roll number" },
      { status: 400 },
    );
  }
  if (!["cash", "upi", "card"].includes(paymentMethod)) {
    return Response.json(
      { error: "Please choose a payment method" },
      { status: 400 },
    );
  }
  if (
    !Array.isArray(body.items) ||
    body.items.length === 0 ||
    body.items.length > 20
  ) {
    return Response.json(
      { error: "Your order must contain between 1 and 20 items" },
      { status: 400 },
    );
  }

  const requested = new Map<number, number>();
  for (const line of body.items) {
    const id = Number(line.menuItemId);
    const qty = Math.floor(Number(line.quantity));
    if (!Number.isInteger(id) || id <= 0 || !Number.isInteger(qty) || qty < 1 || qty > 10) {
      return Response.json({ error: "Invalid item or quantity" }, { status: 400 });
    }
    requested.set(id, (requested.get(id) ?? 0) + qty);
  }

  const menuRows = await db
    .select()
    .from(menuItems)
    .where(
      inArray(
        menuItems.id,
        [...requested.keys()],
      ),
    );

  const byId = new Map(menuRows.map((m) => [m.id, m]));
  const lines: {
    menuItemId: number;
    name: string;
    quantity: number;
    unitPrice: number;
    subtotal: number;
  }[] = [];

  for (const [menuItemId, quantity] of requested) {
    const item = byId.get(menuItemId);
    if (!item || !item.available) {
      return Response.json(
        { error: "One or more items are unavailable right now" },
        { status: 409 },
      );
    }
    lines.push({
      menuItemId,
      name: item.name,
      quantity,
      unitPrice: item.price,
      subtotal: item.price * quantity,
    });
  }

  const totalAmount = lines.reduce((sum, l) => sum + l.subtotal, 0);

  const created = await db.transaction(async (tx) => {
    const [order] = await tx
      .insert(orders)
      .values({
        token: generateToken(),
        customerName,
        rollNumber,
        room,
        paymentMethod,
        status: "pending",
        totalAmount,
      })
      .returning();

    const insertedItems = await tx
      .insert(orderItems)
      .values(lines.map((l) => ({ ...l, orderId: order.id })))
      .returning();

    return { ...order, items: insertedItems };
  });

  return Response.json({ order: created }, { status: 201 });
}
