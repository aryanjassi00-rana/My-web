import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Chaipoint · PG Canteen — 3D",
  description:
    "The PG college canteen in 3D: spin the canteen, browse the live menu, place an order and track it on the kitchen board.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-[#0c0a09] text-stone-100 antialiased">{children}</body>
    </html>
  );
}
