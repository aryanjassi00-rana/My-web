"use client";

import dynamic from "next/dynamic";

const CanteenScene = dynamic(() => import("./CanteenScene"), {
  ssr: false,
  loading: () => (
    <div className="flex h-full min-h-72 w-full items-center justify-center text-sm text-amber-200/70">
      🔥 Heating up the 3D canteen…
    </div>
  ),
});

export default function SceneCanvas() {
  return <CanteenScene />;
}
