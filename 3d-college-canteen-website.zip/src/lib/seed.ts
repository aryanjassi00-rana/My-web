import { count } from "drizzle-orm";
import { db } from "@/db";
import { menuItems, type NewMenuItem } from "@/db/schema";

export const MENU_SEED: NewMenuItem[] = [
  // Breakfast
  { name: "Masala Dosa", description: "Crispy rice crepe stuffed with spiced potato, served with sambar & chutney.", category: "breakfast", price: 45, veg: true, spiceLevel: 2, emoji: "🫓", popular: true },
  { name: "Aloo Paratha", description: "Stuffed whole-wheat paratha with butter on top, with curd & pickle.", category: "breakfast", price: 40, veg: true, spiceLevel: 1, emoji: "🍞" },
  { name: "Egg Bhurji Pav", description: "Spicy scrambled eggs on buttered pav with onions & green chillies.", category: "breakfast", price: 50, veg: false, spiceLevel: 2, emoji: "🍳", popular: true },
  { name: "Idli Sambar (2 pcs)", description: "Steamed rice cakes with sambar and coconut chutney.", category: "breakfast", price: 30, veg: true, spiceLevel: 1, emoji: "🥟" },
  { name: "Poha", description: "Flattened rice tempered with mustard seeds, peanuts & curry leaves.", category: "breakfast", price: 25, veg: true, spiceLevel: 1, emoji: "🍚" },
  { name: "Upma", description: "Savory semolina porridge with veggies and a hint of lemon.", category: "breakfast", price: 25, veg: true, spiceLevel: 0, emoji: "🥣" },

  // Snacks
  { name: "Veg Sandwich", description: "Grilled sandwich with tomato, cucumber, onion & mint chutney.", category: "snacks", price: 35, veg: true, spiceLevel: 0, emoji: "🥪", popular: true },
  { name: "Paneer Tikka Sandwich", description: "Grilled sandwich loaded with spiced paneer tikka & veggies.", category: "snacks", price: 55, veg: true, spiceLevel: 2, emoji: "🧀" },
  { name: "Samosa (2 pcs)", description: "Deep-fried pastry stuffed with spiced potato & peas, with chutney.", category: "snacks", price: 20, veg: true, spiceLevel: 2, emoji: "🥟", popular: true },
  { name: "Veg Cutlet", description: "Crispy mashed-veg patty, the classic canteen evening snack.", category: "snacks", price: 25, veg: true, spiceLevel: 1, emoji: "🍔" },
  { name: "French Fries", description: "Golden fries with peri-peri seasoning and ketchup.", category: "snacks", price: 40, veg: true, spiceLevel: 0, emoji: "🍟", popular: true },
  { name: "Paneer Pakora", description: "Cottage cheese fritters in spiced gram flour batter.", category: "snacks", price: 45, veg: true, spiceLevel: 2, emoji: "🍢" },
  { name: "Maggi Masala", description: "Instant noodles cooked canteen-style with veggies & extra masala.", category: "snacks", price: 35, veg: true, spiceLevel: 3, emoji: "🍜", popular: true },
  { name: "Chicken Nuggets (6 pcs)", description: "Crispy chicken nuggets with mayo dip.", category: "snacks", price: 70, veg: false, spiceLevel: 1, emoji: "🍗" },

  // Meals
  { name: "Veg Thali", description: "Roti, dal, sabzi, rice, salad & pickle — the full canteen thali.", category: "meals", price: 70, veg: true, spiceLevel: 1, emoji: "🍛", popular: true },
  { name: "Chicken Biryani", description: "Aromatic basmati rice layered with spiced chicken & fried onion.", category: "meals", price: 110, veg: false, spiceLevel: 3, emoji: "🍚", popular: true },
  { name: "Veg Biryani", description: "Fragrant rice with mixed vegetables, saffron & raita.", category: "meals", price: 80, veg: true, spiceLevel: 2, emoji: "🌿" },
  { name: "Rajma Chawal", description: "Kidney bean curry with steamed rice and ghee on top.", category: "meals", price: 65, veg: true, spiceLevel: 2, emoji: "🫘" },
  { name: "Chole Bhature (2 pcs)", description: "Puffed bhature with spicy chole, onion & pickle.", category: "meals", price: 60, veg: true, spiceLevel: 3, emoji: "🫓" },
  { name: "Egg Fried Rice", description: "Wok-tossed rice with egg, veggies & soy sauce.", category: "meals", price: 75, veg: false, spiceLevel: 1, emoji: "🍳" },
  { name: "Veg Fried Rice", description: "Wok-tossed rice with mixed veggies & spring onion.", category: "meals", price: 60, veg: true, spiceLevel: 1, emoji: "🥗" },
  { name: "Chicken Fried Rice", description: "Wok-tossed rice with chicken, egg & veggies.", category: "meals", price: 95, veg: false, spiceLevel: 2, emoji: "🍗" },

  // Beverages
  { name: "Masala Chai", description: "Adrak elaichi chai boiled fresh — the soul of the canteen.", category: "beverages", price: 15, veg: true, spiceLevel: 0, emoji: "🍵", popular: true },
  { name: "Cold Coffee", description: "Blended iced coffee with milk & a scoop of ice cream.", category: "beverages", price: 50, veg: true, spiceLevel: 0, emoji: "🥤", popular: true },
  { name: "Lemon Soda", description: "Fizzy sweet-salt lemon soda with mint.", category: "beverages", price: 25, veg: true, spiceLevel: 0, emoji: "🍋" },
  { name: "Mango Shake", description: "Thick mango milkshake with ice cream.", category: "beverages", price: 60, veg: true, spiceLevel: 0, emoji: "🥭" },
  { name: "Badam Milk", description: "Warm saffron almond milk, perfect for winters.", category: "beverages", price: 45, veg: true, spiceLevel: 0, emoji: "🥛" },

  // Desserts
  { name: "Gulab Jamun (2 pcs)", description: "Soft milk dumplings soaked in rose syrup.", category: "desserts", price: 40, veg: true, spiceLevel: 0, emoji: "🍡", popular: true },
  { name: "Ice Cream Cup", description: "Vanilla scoop with chocolate syrup & nuts.", category: "desserts", price: 35, veg: true, spiceLevel: 0, emoji: "🍨" },
  { name: "Kheer", description: "Creamy rice pudding with cardamom & dry fruits.", category: "desserts", price: 35, veg: true, spiceLevel: 0, emoji: "🍮" },
  { name: "Chocolate Brownie", description: "Warm fudgy brownie with a scoop of vanilla ice cream.", category: "desserts", price: 65, veg: true, spiceLevel: 0, emoji: "🍫", popular: true },
];

let seedPromise: Promise<void> | null = null;

/** Insert the menu seed exactly once per process when the table is empty. */
export function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = (async () => {
      const [{ value }] = await db.select({ value: count() }).from(menuItems);
      if (value === 0) {
        await db.insert(menuItems).values(MENU_SEED);
      }
    })();
  }
  return seedPromise;
}
