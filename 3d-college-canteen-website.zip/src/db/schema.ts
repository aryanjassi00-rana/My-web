import {
  boolean,
  index,
  integer,
  pgEnum,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const menuCategoryEnum = pgEnum("menu_category", [
  "breakfast",
  "snacks",
  "meals",
  "beverages",
  "desserts",
]);

export const orderStatusEnum = pgEnum("order_status", [
  "pending",
  "preparing",
  "ready",
  "completed",
  "cancelled",
]);

export const paymentMethodEnum = pgEnum("payment_method", [
  "cash",
  "upi",
  "card",
]);

export const menuItems = pgTable("menu_items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  category: menuCategoryEnum("category").notNull(),
  /** Price in whole INR rupees. */
  price: integer("price").notNull(),
  veg: boolean("veg").notNull().default(true),
  /** 0 = not spicy, 1 = mild, 2 = medium, 3 = extra hot. */
  spiceLevel: integer("spice_level").notNull().default(0),
  emoji: text("emoji").notNull().default("🍽️"),
  popular: boolean("popular").notNull().default(false),
  available: boolean("available").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const orders = pgTable(
  "orders",
  {
    id: serial("id").primaryKey(),
    token: text("token").notNull().unique(),
    customerName: text("customer_name").notNull(),
    rollNumber: text("roll_number").notNull(),
    room: text("room").notNull().default(""),
    paymentMethod: paymentMethodEnum("payment_method").notNull().default("cash"),
    status: orderStatusEnum("status").notNull().default("pending"),
    /** Total in whole INR rupees. */
    totalAmount: integer("total_amount").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    index("orders_status_idx").on(table.status),
    index("orders_created_at_idx").on(table.createdAt),
  ],
);

export const orderItems = pgTable(
  "order_items",
  {
    id: serial("id").primaryKey(),
    orderId: integer("order_id")
      .notNull()
      .references(() => orders.id, { onDelete: "cascade" }),
    menuItemId: integer("menu_item_id")
      .notNull()
      .references(() => menuItems.id),
    /** Snapshot of the item name at order time. */
    name: text("name").notNull(),
    quantity: integer("quantity").notNull(),
    unitPrice: integer("unit_price").notNull(),
    subtotal: integer("subtotal").notNull(),
  },
  (table) => [index("order_items_order_id_idx").on(table.orderId)],
);

export type MenuItem = typeof menuItems.$inferSelect;
export type NewMenuItem = typeof menuItems.$inferInsert;
export type Order = typeof orders.$inferSelect;
export type NewOrder = typeof orders.$inferInsert;
export type OrderItem = typeof orderItems.$inferSelect;

export type OrderWithItems = Order & { items: OrderItem[] };
