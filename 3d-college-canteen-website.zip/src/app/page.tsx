import { asc, desc, inArray } from "drizzle-orm";
import { db } from "@/db";
import { menuItems, orderItems, orders, type OrderWithItems } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import CanteenApp from "@/components/CanteenApp";

export const dynamic = "force-dynamic";

async function getData() {
  await ensureSeeded();

  const items = await db
    .select()
    .from(menuItems)
    .orderBy(asc(menuItems.category), asc(menuItems.name));

  const recentOrders = await db
    .select()
    .from(orders)
    .orderBy(desc(orders.createdAt))
    .limit(30);

  const itemsRows =
    recentOrders.length > 0
      ? await db
          .select()
          .from(orderItems)
          .where(
            inArray(
              orderItems.orderId,
              recentOrders.map((o) => o.id),
            ),
          )
      : [];

  const byOrder = new Map<number, typeof itemsRows>();
  for (const row of itemsRows) {
    const list = byOrder.get(row.orderId) ?? [];
    list.push(row);
    byOrder.set(row.orderId, list);
  }

  const ordersWithItems: OrderWithItems[] = recentOrders.map((o) => ({
    ...o,
    items: (byOrder.get(o.id) ?? []).sort((a, b) => a.id - b.id),
  }));

  return { items, orders: ordersWithItems };
}

export default async function HomePage() {
  const { items, orders: recentOrders } = await getData();
  return <CanteenApp initialItems={items} initialOrders={recentOrders} />;
}
