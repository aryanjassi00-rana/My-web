"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import SceneCanvas from "@/components/SceneCanvas";
import {
  CATEGORIES,
  STATUS_META,
  NEXT_STATUS,
  formatINR,
  formatTime,
  type CategoryId,
  type MenuItem,
  type OrderStatus,
  type OrderWithItems,
  type PlaceOrderPayload,
} from "@/lib/types";

const PAYMENT_OPTIONS: { id: "cash" | "upi" | "card"; label: string; emoji: string }[] = [
  { id: "cash", label: "Cash at counter", emoji: "💵" },
  { id: "upi", label: "UPI", emoji: "📱" },
  { id: "card", label: "Card", emoji: "💳" },
];

export default function CanteenApp({
  initialItems,
  initialOrders,
}: {
  initialItems: MenuItem[];
  initialOrders: OrderWithItems[];
}) {
  const [items] = useState<MenuItem[]>(initialItems);
  const [orders, setOrders] = useState<OrderWithItems[]>(initialOrders);
  const [category, setCategory] = useState<CategoryId>("all");
  const [cart, setCart] = useState<Map<number, number>>(new Map());
  const [cartOpen, setCartOpen] = useState(false);
  const [placing, setPlacing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [placed, setPlaced] = useState<OrderWithItems | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const [name, setName] = useState("");
  const [roll, setRoll] = useState("");
  const [room, setRoom] = useState("");
  const [payment, setPayment] = useState<"cash" | "upi" | "card">("upi");

  const menuRef = useRef<HTMLElement>(null);
  const boardRef = useRef<HTMLElement>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2200);
  }, []);

  const refreshOrders = useCallback(async () => {
    try {
      const res = await fetch("/api/orders", { cache: "no-store" });
      if (res.ok) {
        const data = (await res.json()) as { orders: OrderWithItems[] };
        setOrders(data.orders);
      }
    } catch {
      /* keep existing orders */
    }
  }, []);

  useEffect(() => {
    const id = setInterval(refreshOrders, 8000);
    return () => clearInterval(id);
  }, [refreshOrders]);

  const lines = useMemo(
    () =>
      [...cart.entries()]
        .map(([id, quantity]) => ({
          item: items.find((i) => i.id === id),
          quantity,
        }))
        .filter((l): l is { item: MenuItem; quantity: number } => Boolean(l.item)),
    [cart, items],
  );

  const cartCount = useMemo(
    () => [...cart.values()].reduce((a, b) => a + b, 0),
    [cart],
  );
  const cartTotal = useMemo(
    () => lines.reduce((sum, l) => sum + l.item.price * l.quantity, 0),
    [lines],
  );

  const visibleItems = useMemo(
    () =>
      (category === "all" ? items : items.filter((i) => i.category === category)).sort(
        (a, b) => Number(b.popular) - Number(a.popular) || a.price - b.price,
      ),
    [items, category],
  );

  const todayCount = useMemo(() => {
    const today = new Date().toDateString();
    return orders.filter((o) => new Date(o.createdAt).toDateString() === today).length;
  }, [orders]);

  const addToCart = useCallback(
    (item: MenuItem) => {
      setCart((prev) => {
        const next = new Map(prev);
        next.set(item.id, Math.min(10, (next.get(item.id) ?? 0) + 1));
        return next;
      });
      showToast(`${item.emoji} ${item.name} added to your order`);
    },
    [showToast],
  );

  const setQty = useCallback((id: number, qty: number) => {
    setCart((prev) => {
      const next = new Map(prev);
      if (qty <= 0) next.delete(id);
      else next.set(id, Math.min(10, qty));
      return next;
    });
  }, []);

  const placeOrder = useCallback(async () => {
    setError(null);
    if (lines.length === 0) {
      setError("Add at least one item to place an order.");
      return;
    }
    if (name.trim().length < 2) {
      setError("Please enter your full name.");
      return;
    }
    if (roll.trim().length < 3) {
      setError("Please enter your roll number.");
      return;
    }
    const payload: PlaceOrderPayload = {
      customerName: name.trim(),
      rollNumber: roll.trim().toUpperCase(),
      room: room.trim(),
      paymentMethod: payment,
      items: lines.map((l) => ({ menuItemId: l.item.id, quantity: l.quantity })),
    };
    setPlacing(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Could not place the order. Try again.");
        return;
      }
      setPlaced(data.order as OrderWithItems);
      setCart(new Map());
      setCartOpen(false);
      await refreshOrders();
    } catch {
      setError("Network error — please try again.");
    } finally {
      setPlacing(false);
    }
  }, [lines, name, roll, room, payment, refreshOrders]);

  const advanceStatus = useCallback(
    async (order: OrderWithItems) => {
      const next = NEXT_STATUS[order.status as OrderStatus];
      if (!next) return;
      await fetch(`/api/orders/${order.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: next }),
      });
      await refreshOrders();
    },
    [refreshOrders],
  );

  const scrollTo = (ref: React.RefObject<HTMLElement | null>) =>
    ref.current?.scrollIntoView({ behavior: "smooth", block: "start" });

  return (
    <div className="min-h-screen bg-[#0c0a09] text-stone-100">
      {/* ------------------------------- header ------------------------------- */}
      <header className="sticky top-0 z-40 border-b border-amber-500/15 bg-[#0c0a09]/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-amber-400 to-orange-600 text-xl shadow-lg shadow-orange-900/50">
              🍽️
            </div>
            <div>
              <p className="font-extrabold tracking-tight text-amber-300">
                CHAIPOINT <span className="text-stone-400">·</span> PG CANTEEN
              </p>
              <p className="text-[11px] uppercase tracking-[0.2em] text-stone-500">
                PG Block · Open 7 AM – 9 PM
              </p>
            </div>
          </div>
          <nav className="hidden items-center gap-6 text-sm text-stone-300 md:flex">
            <button onClick={() => scrollTo(menuRef)} className="transition hover:text-amber-300">
              Menu
            </button>
            <button onClick={() => scrollTo(boardRef)} className="transition hover:text-amber-300">
              Live Kitchen
            </button>
          </nav>
          <button
            onClick={() => setCartOpen(true)}
            className="relative rounded-xl bg-amber-400 px-4 py-2 text-sm font-bold text-stone-950 shadow-lg shadow-amber-500/25 transition hover:bg-amber-300"
          >
            🛒 Cart
            {cartCount > 0 && (
              <span className="absolute -right-2 -top-2 grid h-6 w-6 place-items-center rounded-full bg-orange-600 text-xs font-bold text-white ring-2 ring-[#0c0a09]">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* -------------------------------- hero -------------------------------- */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(245,158,11,0.14),transparent_60%)]" />
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1.05fr_1fr] lg:py-20">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-amber-500/30 bg-amber-500/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.18em] text-amber-300">
              <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-400" />
              Open now · 7 AM – 9 PM
            </span>
            <h1 className="mt-6 text-[clamp(2.6rem,6vw,4.6rem)] font-black leading-[1.02] tracking-tight">
              Your campus canteen,
              <span className="block bg-gradient-to-r from-amber-300 via-orange-400 to-rose-400 bg-clip-text text-transparent">
                now in 3D.
              </span>
            </h1>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-stone-400 sm:text-lg">
              Spin the canteen, pick your favourite from the live menu and place your
              order in seconds. Hot masala dosa to cold coffee — track it on the live
              kitchen board until it&apos;s ready. Roll number required, hunger optional.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <button
                onClick={() => scrollTo(menuRef)}
                className="rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-6 py-3 font-bold text-stone-950 shadow-lg shadow-orange-900/50 transition hover:brightness-110"
              >
                🍜 Browse the Menu
              </button>
              <button
                onClick={() => scrollTo(boardRef)}
                className="rounded-xl border border-stone-700 bg-stone-900/60 px-6 py-3 font-semibold text-stone-200 transition hover:border-amber-500/50 hover:text-amber-300"
              >
                📡 Live Kitchen Board
              </button>
            </div>
            <div className="mt-10 grid max-w-lg grid-cols-3 gap-4">
              {[
                { value: `${items.length}+`, label: "menu items" },
                { value: `${todayCount}`, label: "orders today" },
                { value: "~12 min", label: "avg. prep time" },
              ].map((s) => (
                <div
                  key={s.label}
                  className="rounded-2xl border border-stone-800 bg-stone-900/60 p-4 text-center"
                >
                  <p className="text-xl font-black text-amber-300 sm:text-2xl">{s.value}</p>
                  <p className="mt-1 text-[11px] uppercase tracking-wider text-stone-500">
                    {s.label}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* 3D scene */}
          <div className="relative">
            <div className="absolute -inset-4 rounded-[2rem] bg-gradient-to-br from-amber-500/20 via-transparent to-orange-600/20 blur-2xl" />
            <div className="relative h-[420px] overflow-hidden rounded-[1.8rem] border border-amber-500/20 bg-[#0c0a09] shadow-2xl shadow-black/60 sm:h-[520px]">
              <SceneCanvas />
              <div className="pointer-events-none absolute left-4 top-4 rounded-full border border-white/10 bg-black/50 px-3 py-1.5 text-xs text-stone-300 backdrop-blur">
                🖱️ Drag to rotate · Scroll to zoom
              </div>
              <div className="pointer-events-none absolute bottom-4 right-4 rounded-full border border-amber-400/30 bg-black/50 px-3 py-1.5 text-xs font-semibold text-amber-300 backdrop-blur">
                🍔 Fresh &amp; hot, always
              </div>
            </div>
          </div>
        </div>

        {/* marquee */}
        <div className="relative border-y border-amber-500/15 bg-amber-500/5 py-3">
          <div className="marquee flex whitespace-nowrap text-sm font-semibold text-amber-200/90">
            {[0, 1].map((n) => (
              <span key={n} className="flex shrink-0">
                {[
                  "Today's special: Masala Dosa ₹45",
                  "Chicken Biryani ₹110 — chef's pick",
                  "Maggi Masala ₹35 — extra spicy",
                  "Masala Chai ₹15 — unlimited refills in hostel",
                  "Gulab Jamun ₹40 — 2 pcs",
                  "Free delivery to hostel blocks after 6 PM",
                ].map((t) => (
                  <span key={t} className="mx-8">
                    ✦ {t}
                  </span>
                ))}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* -------------------------------- menu -------------------------------- */}
      <section ref={menuRef} className="mx-auto max-w-7xl scroll-mt-24 px-4 py-16 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.25em] text-amber-400">
              The Menu
            </p>
            <h2 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">
              What&apos;s cooking today?
            </h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((c) => (
              <button
                key={c.id}
                onClick={() => setCategory(c.id)}
                className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
                  category === c.id
                    ? "bg-amber-400 text-stone-950 shadow-lg shadow-amber-500/25"
                    : "border border-stone-700 bg-stone-900/60 text-stone-300 hover:border-amber-500/50 hover:text-amber-300"
                }`}
              >
                {c.emoji} {c.label}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {visibleItems.map((item) => {
            const qty = cart.get(item.id) ?? 0;
            return (
              <article
                key={item.id}
                className="group flex flex-col rounded-2xl border border-stone-800 bg-stone-900/60 p-5 transition hover:-translate-y-1 hover:border-amber-500/40 hover:shadow-xl hover:shadow-orange-950/40"
              >
                <div className="flex items-start justify-between">
                  <div className="grid h-14 w-14 place-items-center rounded-xl bg-gradient-to-br from-stone-800 to-stone-900 text-3xl shadow-inner ring-1 ring-stone-700/60 transition group-hover:scale-110">
                    {item.emoji}
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <span
                      className={`rounded-full px-2 py-0.5 text-[10px] font-bold ring-1 ${
                        item.veg
                          ? "bg-emerald-400/10 text-emerald-300 ring-emerald-400/30"
                          : "bg-red-400/10 text-red-300 ring-red-400/30"
                      }`}
                    >
                      {item.veg ? "● VEG" : "▲ NON-VEG"}
                    </span>
                    {item.popular && (
                      <span className="rounded-full bg-amber-400/15 px-2 py-0.5 text-[10px] font-bold text-amber-300 ring-1 ring-amber-400/30">
                        ⭐ Popular
                      </span>
                    )}
                  </div>
                </div>
                <h3 className="mt-4 font-bold leading-snug">{item.name}</h3>
                <p className="mt-1 flex-1 text-sm leading-relaxed text-stone-400">
                  {item.description}
                </p>
                <div className="mt-3 flex items-center justify-between">
                  <span className="text-lg font-black text-amber-300">
                    {formatINR(item.price)}
                  </span>
                  <span className="text-xs text-stone-500">
                    {item.spiceLevel > 0
                      ? "🌶️".repeat(item.spiceLevel)
                      : "🌿 mild"}
                  </span>
                </div>
                <div className="mt-4">
                  {qty === 0 ? (
                    <button
                      onClick={() => addToCart(item)}
                      className="w-full rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 py-2.5 text-sm font-bold text-stone-950 transition hover:brightness-110"
                    >
                      + Add to order
                    </button>
                  ) : (
                    <div className="flex items-center justify-between rounded-xl border border-amber-500/40 bg-amber-500/10 px-2 py-1.5">
                      <button
                        onClick={() => setQty(item.id, qty - 1)}
                        className="grid h-8 w-8 place-items-center rounded-lg bg-stone-800 font-bold text-amber-300 transition hover:bg-stone-700"
                      >
                        −
                      </button>
                      <span className="font-bold text-amber-300">
                        {qty} · {formatINR(item.price * qty)}
                      </span>
                      <button
                        onClick={() => setQty(item.id, qty + 1)}
                        className="grid h-8 w-8 place-items-center rounded-lg bg-amber-400 font-bold text-stone-950 transition hover:bg-amber-300"
                      >
                        +
                      </button>
                    </div>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* ---------------------------- live kitchen ---------------------------- */}
      <section
        ref={boardRef}
        className="border-y border-amber-500/15 bg-[#100d0a] py-16 scroll-mt-16"
      >
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.25em] text-amber-400">
                Live Kitchen Board
              </p>
              <h2 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">
                Track your order 📡
              </h2>
              <p className="mt-2 max-w-lg text-sm text-stone-400">
                Orders appear here the moment they&apos;re placed. Watch the status move
                from <span className="text-amber-300">Pending</span> →{" "}
                <span className="text-sky-300">Preparing</span> →{" "}
                <span className="text-emerald-300">Ready</span>.
              </p>
            </div>
            <button
              onClick={refreshOrders}
              className="rounded-xl border border-stone-700 bg-stone-900/60 px-4 py-2 text-sm font-semibold text-stone-300 transition hover:border-amber-500/50 hover:text-amber-300"
            >
              ↻ Refresh
            </button>
          </div>

          {orders.length === 0 ? (
            <div className="mt-10 rounded-2xl border border-dashed border-stone-700 p-12 text-center text-stone-500">
              No orders yet — be the first! 🍽️ The board refreshes automatically.
            </div>
          ) : (
            <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {orders.map((order) => {
                const meta = STATUS_META[order.status as OrderStatus];
                const next = NEXT_STATUS[order.status as OrderStatus];
                return (
                  <article
                    key={order.id}
                    className="rounded-2xl border border-stone-800 bg-stone-900/70 p-5"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <p className="font-mono text-sm font-bold text-amber-300">
                        #{order.token}
                      </p>
                      <span
                        className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold ring-1 ${meta.chip}`}
                      >
                        <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} />
                        {meta.label}
                      </span>
                    </div>
                    <p className="mt-3 text-sm font-semibold">
                      {order.customerName}{" "}
                      <span className="text-stone-500">
                        · {order.rollNumber}
                        {order.room ? ` · Room ${order.room}` : ""}
                      </span>
                    </p>
                    <ul className="mt-2 space-y-1 text-sm text-stone-400">
                      {order.items.map((it) => (
                        <li key={it.id} className="flex justify-between gap-2">
                          <span>
                            {it.quantity}× {it.name}
                          </span>
                          <span className="text-stone-500">{formatINR(it.subtotal)}</span>
                        </li>
                      ))}
                    </ul>
                    <div className="mt-4 flex items-center justify-between border-t border-stone-800 pt-3">
                      <div>
                        <p className="text-lg font-black text-amber-300">
                          {formatINR(order.totalAmount)}
                        </p>
                        <p className="text-[11px] text-stone-500">
                          {formatTime(order.createdAt)} ·{" "}
                          {order.paymentMethod.toUpperCase()}
                        </p>
                      </div>
                      {next && (
                        <button
                          onClick={() => advanceStatus(order)}
                          className="rounded-lg bg-stone-800 px-3 py-1.5 text-xs font-bold text-stone-200 transition hover:bg-amber-400 hover:text-stone-950"
                        >
                          Mark {STATUS_META[next].label} →
                        </button>
                      )}
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* ------------------------------- footer ------------------------------- */}
      <footer className="mx-auto max-w-7xl px-4 py-10 text-center sm:px-6">
        <p className="font-extrabold text-amber-300">🍽️ CHAIPOINT · PG CANTEEN</p>
        <p className="mt-2 text-sm text-stone-500">
          PG Block, behind the library · Open 7 AM – 9 PM · Orders are picked up at the
          counter with your token.
        </p>
        <p className="mt-4 text-xs text-stone-600">
          Built with Next.js, React Three Fiber &amp; PostgreSQL — a 3D canteen experience.
        </p>
      </footer>

      {/* ------------------------------ cart drawer ------------------------------ */}
      {cartOpen && (
        <div className="fixed inset-0 z-50">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setCartOpen(false)}
          />
          <aside className="absolute right-0 top-0 flex h-full w-full max-w-md flex-col border-l border-amber-500/20 bg-[#12100c] shadow-2xl">
            <div className="flex items-center justify-between border-b border-stone-800 px-5 py-4">
              <h3 className="text-lg font-black">🛒 Your Order</h3>
              <button
                onClick={() => setCartOpen(false)}
                className="grid h-8 w-8 place-items-center rounded-lg bg-stone-800 text-stone-300 hover:bg-stone-700"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-5 py-4">
              {lines.length === 0 ? (
                <p className="mt-8 text-center text-sm text-stone-500">
                  Your cart is empty. Add something tasty from the menu! 🍜
                </p>
              ) : (
                <ul className="space-y-3">
                  {lines.map(({ item, quantity }) => (
                    <li
                      key={item.id}
                      className="flex items-center gap-3 rounded-xl border border-stone-800 bg-stone-900/70 p-3"
                    >
                      <span className="text-2xl">{item.emoji}</span>
                      <div className="flex-1">
                        <p className="text-sm font-semibold">{item.name}</p>
                        <p className="text-xs text-stone-500">
                          {formatINR(item.price)} each
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setQty(item.id, quantity - 1)}
                          className="grid h-7 w-7 place-items-center rounded-md bg-stone-800 font-bold text-amber-300"
                        >
                          −
                        </button>
                        <span className="w-6 text-center text-sm font-bold">{quantity}</span>
                        <button
                          onClick={() => setQty(item.id, quantity + 1)}
                          className="grid h-7 w-7 place-items-center rounded-md bg-amber-400 font-bold text-stone-950"
                        >
                          +
                        </button>
                      </div>
                      <span className="w-16 text-right text-sm font-bold text-amber-300">
                        {formatINR(item.price * quantity)}
                      </span>
                    </li>
                  ))}
                </ul>
              )}

              <div className="mt-6 space-y-3">
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Full name (e.g. Aarav Sharma)"
                  className="w-full rounded-xl border border-stone-700 bg-stone-900/80 px-4 py-2.5 text-sm outline-none placeholder:text-stone-600 focus:border-amber-500/60"
                />
                <div className="grid grid-cols-2 gap-3">
                  <input
                    value={roll}
                    onChange={(e) => setRoll(e.target.value)}
                    placeholder="Roll no. (PG21CS045)"
                    className="w-full rounded-xl border border-stone-700 bg-stone-900/80 px-4 py-2.5 text-sm outline-none placeholder:text-stone-600 focus:border-amber-500/60"
                  />
                  <input
                    value={room}
                    onChange={(e) => setRoom(e.target.value)}
                    placeholder="Hostel room (B-204)"
                    className="w-full rounded-xl border border-stone-700 bg-stone-900/80 px-4 py-2.5 text-sm outline-none placeholder:text-stone-600 focus:border-amber-500/60"
                  />
                </div>
                <div className="flex gap-2">
                  {PAYMENT_OPTIONS.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => setPayment(p.id)}
                      className={`flex-1 rounded-xl border px-2 py-2 text-xs font-bold transition ${
                        payment === p.id
                          ? "border-amber-400 bg-amber-400/15 text-amber-300"
                          : "border-stone-700 bg-stone-900/60 text-stone-400 hover:border-stone-500"
                      }`}
                    >
                      {p.emoji} {p.label}
                    </button>
                  ))}
                </div>
                {error && (
                  <p className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-2.5 text-sm text-rose-300">
                    {error}
                  </p>
                )}
              </div>
            </div>

            <div className="border-t border-stone-800 px-5 py-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-stone-400">Total</span>
                <span className="text-2xl font-black text-amber-300">
                  {formatINR(cartTotal)}
                </span>
              </div>
              <button
                onClick={placeOrder}
                disabled={placing || lines.length === 0}
                className="mt-3 w-full rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 py-3.5 font-black text-stone-950 shadow-lg shadow-orange-900/50 transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {placing ? "Placing order…" : `Place Order · ${formatINR(cartTotal)}`}
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* ---------------------------- success modal ---------------------------- */}
      {placed && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-3xl border border-amber-500/30 bg-[#171310] p-8 text-center shadow-2xl">
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-emerald-400/15 text-4xl ring-1 ring-emerald-400/40">
              ✅
            </div>
            <h3 className="mt-4 text-2xl font-black">Order placed!</h3>
            <p className="mt-2 text-sm text-stone-400">
              Show this token at the counter when your order is ready:
            </p>
            <p className="mt-4 rounded-2xl border border-dashed border-amber-400/50 bg-amber-400/10 px-4 py-3 font-mono text-2xl font-black tracking-widest text-amber-300">
              #{placed.token}
            </p>
            <p className="mt-3 text-sm text-stone-400">
              {placed.items.length} item(s) · {formatINR(placed.totalAmount)} ·{" "}
              {placed.paymentMethod.toUpperCase()}
            </p>
            <div className="mt-6 flex gap-3">
              <button
                onClick={() => {
                  setPlaced(null);
                  scrollTo(boardRef);
                }}
                className="flex-1 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 py-3 font-bold text-stone-950 transition hover:brightness-110"
              >
                Track on kitchen board
              </button>
              <button
                onClick={() => setPlaced(null)}
                className="rounded-xl border border-stone-700 px-5 py-3 font-semibold text-stone-300 transition hover:border-amber-500/50"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* toast */}
      {toast && (
        <div className="fixed bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-full border border-amber-500/30 bg-stone-900/95 px-5 py-2.5 text-sm font-semibold text-amber-200 shadow-xl">
          {toast}
        </div>
      )}
    </div>
  );
}
