import { asc, eq, type SQL } from "drizzle-orm";
import type { NextRequest } from "next/server";
import { db } from "@/db";
import { menuItems } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { CATEGORIES, type CategoryId } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  await ensureSeeded();

  const categoryParam = request.nextUrl.searchParams.get("category");
  const category = CATEGORIES.some((c) => c.id === categoryParam)
    ? (categoryParam as CategoryId)
    : null;

  const conditions: SQL[] = [];
  if (category && category !== "all") {
    conditions.push(eq(menuItems.category, category));
  }

  const items = await db
    .select()
    .from(menuItems)
    .where(conditions.length ? conditions[0] : undefined)
    .orderBy(asc(menuItems.category), asc(menuItems.popular), asc(menuItems.name));

  return Response.json({ items });
}
