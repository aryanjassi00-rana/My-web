"use client";

import { useMemo, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { ContactShadows, Float, Grid, OrbitControls } from "@react-three/drei";
import * as THREE from "three";
import type { Group, Mesh, MeshStandardMaterial } from "three";

/* ---------------------------------- helpers --------------------------------- */

function Spin({
  speed = 0.9,
  children,
}: {
  speed?: number;
  children: React.ReactNode;
}) {
  const ref = useRef<Group>(null);
  useFrame((_, dt) => {
    if (ref.current) ref.current.rotation.y += dt * speed;
  });
  return <group ref={ref}>{children}</group>;
}

function Steam({ position }: { position: [number, number, number] }) {
  const group = useRef<Group>(null);
  const count = 7;
  useFrame((state) => {
    const t = state.clock.elapsedTime;
    group.current?.children.forEach((child, i) => {
      const phase = (i + 0.5) / count;
      const cycle = (t * 0.32 + phase) % 1;
      child.position.y = position[1] + cycle * 1.0;
      child.position.x = position[0] + Math.sin(t * 2 + i) * 0.06 * cycle;
      child.scale.setScalar(0.35 + cycle * 1.4);
      const mat = (child as Mesh).material as MeshStandardMaterial;
      mat.opacity = 0.32 * (1 - cycle);
    });
  });
  return (
    <group ref={group}>
      {Array.from({ length: count }, (_, i) => (
        <mesh key={i} position={[position[0], position[1], position[2]]}>
          <sphereGeometry args={[0.07, 8, 8]} />
          <meshStandardMaterial
            color="#e7e5e4"
            transparent
            opacity={0.3}
            depthWrite={false}
          />
        </mesh>
      ))}
    </group>
  );
}

function useMenuBoardTexture(): THREE.CanvasTexture {
  return useMemo(() => {
    const w = 1024;
    const h = 560;
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (ctx) {
      const g = ctx.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, "#201510");
      g.addColorStop(1, "#120d09");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);
      ctx.strokeStyle = "#f59e0b";
      ctx.lineWidth = 10;
      ctx.strokeRect(16, 16, w - 32, h - 32);
      ctx.textAlign = "center";
      ctx.fillStyle = "#fbbf24";
      ctx.font = "700 56px system-ui, sans-serif";
      ctx.fillText("TODAY'S MENU", w / 2, 96);
      ctx.font = "600 30px system-ui, sans-serif";
      const rows: [string, string][] = [
        ["Masala Dosa", "45"],
        ["Veg Biryani", "80"],
        ["Maggi Masala", "35"],
        ["Masala Chai", "15"],
        ["Gulab Jamun", "40"],
        ["Cold Coffee", "50"],
      ];
      rows.forEach(([name, price], i) => {
        const y = 168 + i * 56;
        ctx.textAlign = "left";
        ctx.fillStyle = "#f5f0e6";
        ctx.fillText(name, 96, y);
        ctx.fillStyle = "#57534e";
        ctx.fillText("·····························", 470, y);
        ctx.textAlign = "right";
        ctx.fillStyle = "#fbbf24";
        ctx.fillText(`₹${price}`, w - 96, y);
      });
      ctx.textAlign = "center";
      ctx.fillStyle = "#d97706";
      ctx.font = "600 26px system-ui, sans-serif";
      ctx.fillText("★ Fresh · Hot · PG Canteen ★", w / 2, h - 44);
    }
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 8;
    return tex;
  }, []);
}

function useNeonTexture(): THREE.CanvasTexture {
  return useMemo(() => {
    const w = 1024;
    const h = 256;
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.fillStyle = "#0c0a09";
      ctx.fillRect(0, 0, w, h);
      ctx.textAlign = "center";
      ctx.font = "800 92px system-ui, sans-serif";
      ctx.shadowColor = "#fb923c";
      ctx.shadowBlur = 34;
      ctx.fillStyle = "#fdba74";
      ctx.fillText("CHAIPOINT", w / 2, 110);
      ctx.shadowBlur = 18;
      ctx.fillStyle = "#fef3c7";
      ctx.font = "600 40px system-ui, sans-serif";
      ctx.fillText("· PG CANTEEN ·", w / 2, 190);
    }
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 8;
    return tex;
  }, []);
}

/* ----------------------------------- food ----------------------------------- */

function Burger() {
  const seeds = useMemo(
    () =>
      Array.from({ length: 7 }, (_, i) => ({
        x: Math.cos(i * 2.4) * 0.2,
        z: Math.sin(i * 2.4) * 0.2,
        y: 0.6,
      })),
    [],
  );
  return (
    <group>
      <mesh position={[0, 0.07, 0]} castShadow>
        <cylinderGeometry args={[0.42, 0.42, 0.14, 24]} />
        <meshStandardMaterial color="#d99a4e" roughness={0.7} />
      </mesh>
      <mesh position={[0, 0.18, 0]} castShadow>
        <cylinderGeometry args={[0.4, 0.4, 0.1, 24]} />
        <meshStandardMaterial color="#6b3f1d" roughness={0.8} />
      </mesh>
      <mesh position={[0, 0.245, 0]} rotation={[0.05, 0, 0.03]}>
        <boxGeometry args={[0.8, 0.035, 0.8]} />
        <meshStandardMaterial color="#ffc531" roughness={0.5} />
      </mesh>
      <mesh position={[0, 0.29, 0]} castShadow>
        <cylinderGeometry args={[0.45, 0.45, 0.07, 24]} />
        <meshStandardMaterial color="#7fb069" roughness={0.9} />
      </mesh>
      <mesh position={[0, 0.4, 0]} scale={[1, 0.6, 1]} castShadow>
        <sphereGeometry args={[0.44, 24, 16]} />
        <meshStandardMaterial color="#e8b06a" roughness={0.65} />
      </mesh>
      {seeds.map((s, i) => (
        <mesh key={i} position={[s.x, s.y, s.z]}>
          <sphereGeometry args={[0.025, 6, 6]} />
          <meshStandardMaterial color="#fff7ed" />
        </mesh>
      ))}
    </group>
  );
}

function PizzaSlice() {
  return (
    <group rotation={[-Math.PI / 2, 0, 0]}>
      <mesh castShadow>
        <cylinderGeometry args={[0.07, 0.62, 0.1, 24, 1, false, -0.55, 1.1]} />
        <meshStandardMaterial color="#f2c14e" roughness={0.6} />
      </mesh>
      <mesh position={[0, 0.055, 0]}>
        <cylinderGeometry args={[0.6, 0.6, 0.02, 24, 1, false, -0.58, 1.16]} />
        <meshStandardMaterial color="#e0a83c" roughness={0.8} />
      </mesh>
      {[
        [0.22, 0.1],
        [0.34, -0.12],
        [0.18, -0.26],
        [0.42, 0.06],
      ].map(([x, z], i) => (
        <mesh key={i} position={[x, 0.062, z]}>
          <cylinderGeometry args={[0.075, 0.075, 0.03, 12]} />
          <meshStandardMaterial color="#c0392b" roughness={0.5} />
        </mesh>
      ))}
    </group>
  );
}

function CoffeeCup() {
  return (
    <group>
      <mesh position={[0, 0.24, 0]} castShadow>
        <cylinderGeometry args={[0.27, 0.2, 0.48, 20]} />
        <meshStandardMaterial color="#f5f0e6" roughness={0.35} />
      </mesh>
      <mesh position={[0, 0.485, 0]}>
        <cylinderGeometry args={[0.25, 0.25, 0.04, 20]} />
        <meshStandardMaterial color="#4b2e1e" roughness={0.4} />
      </mesh>
      <mesh position={[0.31, 0.24, 0]} rotation={[0, Math.PI / 2, 0]}>
        <torusGeometry args={[0.12, 0.035, 10, 20, Math.PI]} />
        <meshStandardMaterial color="#f5f0e6" roughness={0.35} />
      </mesh>
    </group>
  );
}

function Fries() {
  const sticks = useMemo(
    () =>
      Array.from({ length: 9 }, (_, i) => ({
        x: (Math.random() - 0.5) * 0.34,
        z: (Math.random() - 0.5) * 0.34,
        rot: (Math.random() - 0.5) * 0.5,
        h: 0.34 + Math.random() * 0.16,
      })),
    [],
  );
  return (
    <group>
      <mesh position={[0, 0.16, 0]} castShadow>
        <boxGeometry args={[0.36, 0.32, 0.36]} />
        <meshStandardMaterial color="#d62828" roughness={0.6} />
      </mesh>
      {sticks.map((s, i) => (
        <mesh
          key={i}
          position={[s.x, 0.32 + s.h / 2, s.z]}
          rotation={[s.rot * 0.4, 0, s.rot]}
        >
          <boxGeometry args={[0.05, s.h, 0.05]} />
          <meshStandardMaterial color="#ffd166" roughness={0.6} />
        </mesh>
      ))}
    </group>
  );
}

function Donut() {
  const sprinkles = useMemo(
    () =>
      Array.from({ length: 14 }, (_, i) => {
        const a = (i / 14) * Math.PI * 2;
        return {
          x: Math.cos(a) * 0.3,
          z: Math.sin(a) * 0.3,
          rot: Math.random() * Math.PI,
          color: ["#f43f5e", "#38bdf8", "#facc15", "#4ade80", "#e879f9"][i % 5],
        };
      }),
    [],
  );
  return (
    <group rotation={[-Math.PI / 2, 0, 0]}>
      <mesh castShadow>
        <torusGeometry args={[0.3, 0.17, 16, 32]} />
        <meshStandardMaterial color="#f472b6" roughness={0.45} />
      </mesh>
      <mesh>
        <torusGeometry args={[0.3, 0.185, 16, 32]} />
        <meshStandardMaterial color="#ec4899" roughness={0.4} />
      </mesh>
      {sprinkles.map((s, i) => (
        <mesh key={i} position={[s.x, 0.16, s.z]} rotation={[0, 0, s.rot]}>
          <boxGeometry args={[0.07, 0.02, 0.025]} />
          <meshStandardMaterial color={s.color} />
        </mesh>
      ))}
    </group>
  );
}

function Samosa() {
  return (
    <group rotation={[0, 0, Math.PI / 4]}>
      <mesh castShadow position={[0, 0.16, 0]} rotation={[0, Math.PI / 4, 0]}>
        <coneGeometry args={[0.32, 0.72, 4]} />
        <meshStandardMaterial color="#d9a441" roughness={0.75} />
      </mesh>
    </group>
  );
}

function NoodleBowl() {
  return (
    <group>
      <mesh position={[0, 0.14, 0]} castShadow>
        <cylinderGeometry args={[0.36, 0.26, 0.28, 20]} />
        <meshStandardMaterial color="#ea580c" roughness={0.55} />
      </mesh>
      <mesh position={[0, 0.29, 0]}>
        <torusGeometry args={[0.26, 0.1, 10, 20]} />
        <meshStandardMaterial color="#fcd34d" roughness={0.8} />
      </mesh>
      <mesh position={[0.12, 0.5, -0.1]} rotation={[0.35, 0, -0.25]}>
        <cylinderGeometry args={[0.025, 0.025, 0.8, 8]} />
        <meshStandardMaterial color="#a16207" roughness={0.6} />
      </mesh>
      <mesh position={[0.2, 0.5, 0.05]} rotation={[0.3, 0, -0.15]}>
        <cylinderGeometry args={[0.025, 0.025, 0.8, 8]} />
        <meshStandardMaterial color="#a16207" roughness={0.6} />
      </mesh>
    </group>
  );
}

function IceCream() {
  return (
    <group>
      <mesh position={[0, 0.2, 0]} rotation={[Math.PI, 0, 0]} castShadow>
        <coneGeometry args={[0.24, 0.5, 16]} />
        <meshStandardMaterial color="#d9a441" roughness={0.8} />
      </mesh>
      <mesh position={[0, 0.55, 0]} castShadow>
        <sphereGeometry args={[0.27, 20, 14]} />
        <meshStandardMaterial color="#f9a8d4" roughness={0.4} />
      </mesh>
      <mesh position={[0, 0.82, 0]}>
        <sphereGeometry args={[0.07, 10, 8]} />
        <meshStandardMaterial color="#dc2626" emissive="#dc2626" emissiveIntensity={0.6} />
      </mesh>
    </group>
  );
}

/* ------------------------------ scene pieces -------------------------------- */

function PendantLight({ x }: { x: number }) {
  return (
    <group position={[x, 0, -0.6]}>
      <mesh position={[0, 3.9, 0]}>
        <cylinderGeometry args={[0.02, 0.02, 1.7, 8]} />
        <meshStandardMaterial color="#292524" />
      </mesh>
      <mesh position={[0, 3.0, 0]} castShadow>
        <coneGeometry args={[0.42, 0.34, 24, 1, true]} />
        <meshStandardMaterial color="#1c1917" metalness={0.6} roughness={0.4} side={THREE.DoubleSide} />
      </mesh>
      <mesh position={[0, 2.86, 0]}>
        <sphereGeometry args={[0.1, 12, 10]} />
        <meshStandardMaterial
          color="#ffb703"
          emissive="#ffb703"
          emissiveIntensity={3}
        />
      </mesh>
      <pointLight position={[0, 2.7, 0]} color="#ffb703" intensity={16} distance={7} decay={2} />
    </group>
  );
}

function Table({ x, z }: { x: number; z: number }) {
  return (
    <group position={[x, 0, z]}>
      <mesh position={[0, 0.72, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[0.85, 0.85, 0.07, 28]} />
        <meshStandardMaterial color="#a16207" roughness={0.55} />
      </mesh>
      <mesh position={[0, 0.36, 0]}>
        <cylinderGeometry args={[0.07, 0.09, 0.7, 12]} />
        <meshStandardMaterial color="#292524" metalness={0.5} roughness={0.5} />
      </mesh>
      <mesh position={[0, 0.03, 0]}>
        <cylinderGeometry args={[0.34, 0.34, 0.06, 20]} />
        <meshStandardMaterial color="#292524" />
      </mesh>
      {/* stools */}
      {[0, 1].map((i) => (
        <group key={i} position={[i === 0 ? 1.15 : -1.15, 0, 0.25]}>
          <mesh position={[0, 0.46, 0]} castShadow>
            <cylinderGeometry args={[0.27, 0.27, 0.09, 18]} />
            <meshStandardMaterial color="#78350f" roughness={0.6} />
          </mesh>
          <mesh position={[0, 0.23, 0]}>
            <cylinderGeometry args={[0.05, 0.05, 0.44, 10]} />
            <meshStandardMaterial color="#292524" />
          </mesh>
        </group>
      ))}
      {/* a plate + cup on the table */}
      <mesh position={[0.3, 0.78, 0.15]} castShadow>
        <cylinderGeometry args={[0.16, 0.16, 0.03, 18]} />
        <meshStandardMaterial color="#e7e5e4" roughness={0.3} />
      </mesh>
      <mesh position={[-0.25, 0.82, -0.2]} castShadow>
        <cylinderGeometry args={[0.07, 0.055, 0.14, 12]} />
        <meshStandardMaterial color="#f5f0e6" roughness={0.3} />
      </mesh>
      <mesh position={[-0.25, 0.905, -0.2]}>
        <cylinderGeometry args={[0.062, 0.062, 0.015, 12]} />
        <meshStandardMaterial color="#92400e" />
      </mesh>
    </group>
  );
}

function CanteenInterior({ boardTexture, neonTexture }: { boardTexture: THREE.Texture; neonTexture: THREE.Texture }) {
  return (
    <group>
      {/* floor base */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <circleGeometry args={[15, 48]} />
        <meshStandardMaterial color="#171310" roughness={0.95} />
      </mesh>

      {/* back wall */}
      <mesh position={[0, 3, -4.6]} receiveShadow>
        <planeGeometry args={[20, 7]} />
        <meshStandardMaterial color="#211a15" roughness={0.95} />
      </mesh>

      {/* menu board */}
      <mesh position={[0, 3.4, -4.52]}>
        <boxGeometry args={[7.4, 4.1, 0.08]} />
        <meshStandardMaterial color="#0c0a09" />
      </mesh>
      <mesh position={[0, 3.4, -4.47]}>
        <planeGeometry args={[7, 3.8]} />
        <meshBasicMaterial map={boardTexture} toneMapped={false} />
      </mesh>

      {/* neon sign */}
      <mesh position={[-4.6, 2.2, -4.5]} rotation={[0, 0.12, 0]}>
        <planeGeometry args={[3.4, 0.85]} />
        <meshBasicMaterial map={neonTexture} transparent toneMapped={false} />
      </mesh>
      <pointLight position={[-4.6, 2.2, -4.0]} color="#fb923c" intensity={6} distance={5} decay={2} />

      {/* counter */}
      <group position={[0, 0, -3.1]}>
        <mesh position={[0, 0.55, 0]} castShadow receiveShadow>
          <boxGeometry args={[8.4, 1.1, 1.1]} />
          <meshStandardMaterial color="#292524" roughness={0.8} />
        </mesh>
        <mesh position={[0, 1.16, 0]} castShadow>
          <boxGeometry args={[8.8, 0.14, 1.4]} />
          <meshStandardMaterial color="#78350f" roughness={0.35} />
        </mesh>
        <mesh position={[0, 0.72, 0.56]}>
          <boxGeometry args={[8.4, 0.1, 0.04]} />
          <meshStandardMaterial color="#f59e0b" emissive="#f59e0b" emissiveIntensity={1.6} />
        </mesh>
        {/* kadai (wok) with steam */}
        <mesh position={[-2.4, 1.35, 0]} castShadow>
          <cylinderGeometry args={[0.5, 0.42, 0.34, 20]} />
          <meshStandardMaterial color="#3f3f46" metalness={0.8} roughness={0.35} />
        </mesh>
        <mesh position={[-2.4, 1.52, 0]}>
          <cylinderGeometry args={[0.46, 0.46, 0.04, 20]} />
          <meshStandardMaterial color="#b45309" roughness={0.7} />
        </mesh>
        {/* stack of plates */}
        {[0, 1, 2, 3].map((i) => (
          <mesh key={i} position={[2.6, 1.26 + i * 0.045, 0]} castShadow>
            <cylinderGeometry args={[0.34, 0.34, 0.04, 20]} />
            <meshStandardMaterial color="#e7e5e4" roughness={0.25} />
          </mesh>
        ))}
        {/* chai glasses row */}
        {[-0.9, -0.5, -0.1].map((x, i) => (
          <group key={i} position={[x, 1.23, -0.2]}>
            <mesh castShadow>
              <cylinderGeometry args={[0.09, 0.075, 0.2, 12]} />
              <meshStandardMaterial color="#f5f0e6" transparent opacity={0.85} roughness={0.2} />
            </mesh>
            <mesh position={[0, 0.06, 0]}>
              <cylinderGeometry args={[0.078, 0.078, 0.12, 12]} />
              <meshStandardMaterial color="#b45309" transparent opacity={0.9} />
            </mesh>
          </group>
        ))}
        {/* menu stand on counter */}
        <mesh position={[0.9, 1.5, 0.1]} rotation={[-0.25, 0, 0]}>
          <boxGeometry args={[0.9, 0.6, 0.05]} />
          <meshStandardMaterial color="#fbbf24" emissive="#b45309" emissiveIntensity={0.5} roughness={0.6} />
        </mesh>
      </group>

      <Steam position={[-2.4, 1.6, -3.1]} />

      {/* tables */}
      <Table x={-2.7} z={0.9} />
      <Table x={0.1} z={1.6} />
      <Table x={2.8} z={0.8} />

      {/* pendant lights */}
      <PendantLight x={-2.7} />
      <PendantLight x={0.1} />
      <PendantLight x={2.8} />
    </group>
  );
}

function FloatingFood() {
  const items: {
    node: React.ReactNode;
    position: [number, number, number];
    floatSpeed: number;
    spin: number;
    scale: number;
  }[] = [
    { node: <Burger />, position: [-3.4, 1.9, 1.9], floatSpeed: 1.6, spin: 0.7, scale: 1.05 },
    { node: <PizzaSlice />, position: [-1.9, 2.6, 0.7], floatSpeed: 2.1, spin: 1.1, scale: 1.15 },
    { node: <CoffeeCup />, position: [-0.2, 2.0, 1.8], floatSpeed: 1.8, spin: 0.9, scale: 1 },
    { node: <Fries />, position: [1.7, 2.5, 0.8], floatSpeed: 2.3, spin: 1.2, scale: 1 },
    { node: <Donut />, position: [3.3, 1.8, 1.9], floatSpeed: 1.5, spin: 0.8, scale: 1 },
    { node: <Samosa />, position: [-2.5, 3.4, -0.6], floatSpeed: 2.6, spin: 1.4, scale: 0.95 },
    { node: <NoodleBowl />, position: [2.4, 3.3, -0.5], floatSpeed: 2.2, spin: 1.0, scale: 0.9 },
    { node: <IceCream />, position: [0.6, 3.4, -0.3], floatSpeed: 2.8, spin: 1.3, scale: 0.85 },
  ];
  return (
    <group>
      {items.map((f, i) => (
        <group key={i} position={f.position} scale={f.scale}>
          <Float speed={f.floatSpeed} rotationIntensity={0.5} floatIntensity={1.4}>
            <Spin speed={f.spin}>{f.node}</Spin>
          </Float>
        </group>
      ))}
    </group>
  );
}

/* --------------------------------- canvas ----------------------------------- */

export default function CanteenScene() {
  const boardTexture = useMenuBoardTexture();
  const neonTexture = useNeonTexture();

  return (
    <Canvas
      shadows
      dpr={[1, 2]}
      camera={{ position: [0, 2.7, 10], fov: 42, near: 0.1, far: 60 }}
      gl={{ antialias: true }}
    >
      <color attach="background" args={["#0c0a09"]} />
      <fog attach="fog" args={["#0c0a09", 14, 30]} />

      <ambientLight intensity={0.5} />
      <directionalLight
        position={[5, 9, 6]}
        intensity={1.5}
        castShadow
        shadow-mapSize={[1024, 1024]}
        shadow-camera-left={-9}
        shadow-camera-right={9}
        shadow-camera-top={9}
        shadow-camera-bottom={-9}
        shadow-bias={-0.0004}
      />
      <directionalLight position={[-7, 4, -5]} intensity={0.4} color="#93c5fd" />

      <CanteenInterior boardTexture={boardTexture} neonTexture={neonTexture} />
      <FloatingFood />

      <ContactShadows
        position={[0, 0.012, 0]}
        opacity={0.5}
        scale={26}
        blur={2.2}
        far={8}
        resolution={512}
        color="#000000"
      />
      <Grid
        position={[0, 0.006, 0]}
        args={[40, 40]}
        cellSize={0.5}
        cellThickness={0.6}
        cellColor="#26201b"
        sectionSize={2.5}
        sectionThickness={1.1}
        sectionColor="#3f3227"
        fadeDistance={20}
        fadeStrength={1.8}
        infiniteGrid
      />

      <OrbitControls
        target={[0, 1.6, 0]}
        enablePan={false}
        enableZoom
        minDistance={4.5}
        maxDistance={13}
        minPolarAngle={0.9}
        maxPolarAngle={1.52}
        autoRotate
        autoRotateSpeed={0.7}
      />
    </Canvas>
  );
}
