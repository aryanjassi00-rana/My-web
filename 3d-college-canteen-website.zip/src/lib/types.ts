import type { MenuItem, OrderWithItems } from "@/db/schema";

export type { MenuItem, OrderWithItems };

export interface CartLine {
  item: MenuItem;
  quantity: number;
}

export interface PlaceOrderPayload {
  customerName: string;
  rollNumber: string;
  room: string;
  paymentMethod: "cash" | "upi" | "card";
  items: { menuItemId: number; quantity: number }[];
}

export const CATEGORIES = [
  { id: "all", label: "All", emoji: "✨" },
  { id: "breakfast", label: "Breakfast", emoji: "🍳" },
  { id: "snacks", label: "Snacks", emoji: "🍟" },
  { id: "meals", label: "Meals", emoji: "🍛" },
  { id: "beverages", label: "Beverages", emoji: "🍵" },
  { id: "desserts", label: "Desserts", emoji: "🍨" },
] as const;

export type CategoryId = (typeof CATEGORIES)[number]["id"];

export const ORDER_STATUSES = [
  "pending",
  "preparing",
  "ready",
  "completed",
  "cancelled",
] as const;

export type OrderStatus = (typeof ORDER_STATUSES)[number];

export const STATUS_META: Record<
  OrderStatus,
  { label: string; chip: string; dot: string }
> = {
  pending: {
    label: "Pending",
    chip: "bg-amber-400/15 text-amber-300 ring-amber-400/30",
    dot: "bg-amber-400",
  },
  preparing: {
    label: "Preparing",
    chip: "bg-sky-400/15 text-sky-300 ring-sky-400/30",
    dot: "bg-sky-400 animate-pulse",
  },
  ready: {
    label: "Ready",
    chip: "bg-emerald-400/15 text-emerald-300 ring-emerald-400/30",
    dot: "bg-emerald-400 animate-pulse",
  },
  completed: {
    label: "Completed",
    chip: "bg-stone-400/15 text-stone-300 ring-stone-400/30",
    dot: "bg-stone-400",
  },
  cancelled: {
    label: "Cancelled",
    chip: "bg-rose-400/15 text-rose-300 ring-rose-400/30",
    dot: "bg-rose-400",
  },
};

export const NEXT_STATUS: Partial<Record<OrderStatus, OrderStatus>> = {
  pending: "preparing",
  preparing: "ready",
  ready: "completed",
};

export function formatINR(amount: number): string {
  return `₹${amount.toLocaleString("en-IN")}`;
}

export function formatTime(iso: string | Date): string {
  const d = typeof iso === "string" ? new Date(iso) : iso;
  return d.toLocaleTimeString("en-IN", {
    hour: "2-digit",
    minute: "2-digit",
  });
}
